# 3D-Game-Programming
3D using bitblting in Windows.  

These files can kick-start someone new to 3D programming. Each folder contains only one source code file. There is a complete 3D game as well as a simple platformer demo making this a great teaching tool.

These files go along with this [youtube video](http://www.youtube.com/watch?v=Xy9iHveorQE):  
[![3D Game Programming For Beginners](http://img.youtube.com/vi/Xy9iHveorQE/0.jpg)](http://www.youtube.com/watch?v=Xy9iHveorQE)

 
